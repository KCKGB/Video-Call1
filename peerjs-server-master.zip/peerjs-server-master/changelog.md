# PeerServer Changelog

### 0.2.6

* Ensure 16 character IDs.

### 0.2.5

* Takes a `path` option, which the peer server will append PeerJS routes to.
* Add support for configurable server IP address.

### 0.2.1

* Added test suite.
* Locked node dependency for restify.
